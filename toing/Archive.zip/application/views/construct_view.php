<!-- Horizontal Layout -->
  <section class="content">
        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               <b>Halaman sedang</b> <u>dalam perbaikan</u>.
                            </h2>
                            
                        </div>
                        <div class="body">
                            <div class="row clearfix">
                                <center>
                                    <img src="<?=base_url();?>assets/svg/under_construction.svg" width="40%"><br>
                                    <br>
                                    <font size="5px"><b>UNDER CONSTRUCTION!!</b></font>
                                    <br>
                                    <font size="3px">Mohon maaf, halaman yang anda minta sedang dalam perbaikan.</font>
                                </center>
						    </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- #END# Horizontal Layout -->