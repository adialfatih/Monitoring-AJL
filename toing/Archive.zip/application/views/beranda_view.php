<div class="tengah pd50">
    <img src="<?=base_url();?>assets/logo_rjs2.jpg" alt="Logo RJS">
    <h1>Welcome, PT. Rindang Jati Spinning</h1>
    
</div>
            <!-- <div class="formdata">
                <h1>Input Data Pembelian Benang</h1>
                <div class="forminput mt-20">
                    <label for="nama_benang">Nama Benang</label>
                    <input type="text" placeholder="Masukan Nama Benang" name="nama_benang" id="nama_benang">
                </div>
                <div class="forminput mt-20">
                    <label for="bale">Jumlah Bale</label>
                    <input type="text" class="sm" placeholder="Masukan Jumlah Bale" name="bale" id="bale" inputmode="numeric">
                </div>
                <div class="forminput mt-20">
                    <label for="netto">Netto</label>
                    <input type="text" class="sm" placeholder="Netto" name="netto" id="netto" inputmode="numeric" readonly>
                    <span class="smout">Jumlah Bale x 181.44</span>
                </div>
                <div class="forminput mt-20">
                    <label for="karung">Jumlah Karung</label>
                    <input type="text" class="sm" placeholder="Masukan Jumlah Karung" name="karung" id="karung" inputmode="numeric">
                </div>
                <div class="forminput mt-20">
                    <label for="ne">NE</label>
                    <input type="text" class="sm" placeholder="Masukan NE" name="ne" id="ne" inputmode="numeric">
                </div>
                <button class="sbmit">Submit</button>
                <div class="karungan">
                    <div class="box-karung">
                        <span>Kode XE1</span>
                        <label for="beratkarung">Berat Karung</label>
                        <input type="text" id="beratkarung">
                        <label for="jumlahcones">Jumlah Cones</label>
                        <input type="text" name="cones" id="jumlahcones">
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE1</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE2</span>
                    </div>
                    <div class="box-karung">
                        <span>Kode XE3</span>
                    </div>
                </div>
            </div>
        </div>
    </div> -->