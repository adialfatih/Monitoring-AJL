<div class="formdata">
                <!-- <div class="notifikasi-sukses" style="background:#02a82e;color:#fff;padding:15px;border-radius:5px;font-size:14px;">
                    Ini pemberitahuan notifikasi
                </div>
                <div class="notifikasi-gagal" style="background:#de071c;color:#fff;padding:15px;border-radius:5px;font-size:14px;">
                    Ini pemberitahuan notifikasi
                </div> -->
                <?php if($notif=="true"){ ?>
                <div class="notifikasi-sukses" style="background:#02a82e;color:#fff;padding:15px;border-radius:5px;font-size:14px;">
                    Berhasil menyimpan pembelian benang.
                </div>
                <?php } 
                
                $cek_data = $this->data_model->get_byid('produksi_mesin_ajl',['proses'=>'onproses']);
                ?>
                
                <div style="display:flex;align-items:center;justify-content:space-between;">
                    <h1>Produksi Mesin AJL</h1>
                    <a href="<?=base_url('produksi-ajl');?>">
                    <button class="sbmit" id="idSubmitForm" style="width:200px;">Input Produksi</button></a>
                </div>
                <div class="karungan" id="dataKArung">
                    <?php 
                    if($cek_data->num_rows() > 0){
                    foreach($cek_data->result() as $val): 
                        $ex = explode('-', $val->tgl_produksi);
                        $ew = explode(' ', $val->waktu_awal_produksi);
                        $er = explode(':', $ew[1]);
                        $printBln = $ex[2]."-".$this->data_model->printBln2($ex[1])."-".$ex[0];
                        $idsizing=$val->id_beam_sizing;
                        $sizing = $this->data_model->get_byid('beam_sizing', ['id_beam_sizing'=>$idsizing])->row_array();
                        $id1 = $val->id_produksi_mesin;
                    ?>
                    <div class="box-karung dataClick" style="width:350px;cursor:pointer;" id="data-<?=$id1;?>">
                        <span style="font-size:17px;"><a href="<?=base_url('data/produksi/mesin/'.$id1);?>" style="text-decoration:none;color:#0666c7;">Nomor Mesin : <?=$val->no_mesin;?></a></span>
                        <label for="totalkarung">Kode Beam Sizing / Ukuran</label>
                        <input type="text" style="color:#124fb0;" id="totalkarung" value="<?=$sizing['kode_beam'];?> / <?=$sizing['ukuran_panjang'];?>" readonly>
                        <label for="beratkarung" class="mt-10">Tanggal / Waktu Awal Produksi</label>
                        <input type="text" style="color:#124fb0;" id="beratkarung" value="<?=$printBln;?> / <?=$er[0].':'.$er[1];?>" readonly>
                        <label for="pot1" class="mt-10">Jumlah Potongan</label>
                        <input type="text" style="color:#124fb0;" id="pot1" value="0" readonly>
                        <div style="width:100%;display:flex;align-items:center;justify-content:flex-start;">
                            <span style="color:#000;">Status : </span>
                            <span style="color:green;">&nbsp;Sedang Produksi</span>
                        </div>
                    </div>
                    <?php endforeach; 
                    } else {
                        echo "<p>Data Produksi Mesin Tidak Ada</p>";   
                    }?>
                </div>
            </div>
        </div>
    </div>